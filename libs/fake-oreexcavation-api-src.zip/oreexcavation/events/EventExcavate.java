package oreexcavation.events;

import net.minecraftforge.eventbus.api.Event;
import oreexcavation.handlers.MiningAgent;

public class EventExcavate {
    
    public static class Pre extends Event {
        
        public MiningAgent getAgent() {
            return null;
        }
        
    }
    
}
