package oreexcavation.groups;

import net.minecraft.block.BlockState;
import net.minecraft.util.ResourceLocation;

public class BlockEntry {
    
    public BlockEntry(BlockState state) {
    }
    
    public ResourceLocation idName;
    
}
