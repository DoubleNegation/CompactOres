package oreexcavation.groups;


import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;

public class BlockEntry {
    
    public BlockEntry(BlockState state) {
    }
    
    public ResourceLocation idName;
    
}
