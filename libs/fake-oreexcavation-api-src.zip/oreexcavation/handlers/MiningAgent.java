package oreexcavation.handlers;

import net.minecraft.block.BlockState;
import oreexcavation.groups.BlockEntry;

import java.util.Set;

public class MiningAgent {
    
    public Set<BlockEntry> blockGroup;
    
    public BlockState state;
    
}
